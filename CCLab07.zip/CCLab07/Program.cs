﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace CCLab07
{

	public class Parser
	{
		private readonly List<string> tokens;
		private int currentTokenIndex = 0;

		public Parser(string input)
		{
			tokens = Tokenize(input);  // Tokenize input
		}

		private string CurrentToken => currentTokenIndex < tokens.Count ? tokens[currentTokenIndex] : null;

		private void NextToken() => currentTokenIndex++;

		// Method to parse the input starting from <Expression>
		public void Parse()
		{
			ParseExpression();
			if (CurrentToken != null)
			{
				throw new Exception($"Syntax Error: Unexpected token '{CurrentToken}' at the end.");
			}
		}

		// Grammar Rule: <Expression> ::= <Term> "+" <Expression> | <Term>
		private void ParseExpression()
		{
			ParseTerm();
			if (CurrentToken == "+")
			{
				NextToken();  // Consume '+'
				ParseExpression();
			}
		}

		// Grammar Rule: <Term> ::= <Factor> "*" <Term> | <Factor>
		private void ParseTerm()
		{
			ParseFactor();
			if (CurrentToken == "*")
			{
				NextToken();  // Consume '*'
				ParseTerm();
			}
		}

		// Grammar Rule: <Factor> ::= "(" <Expression> ")" | <Number>
		private void ParseFactor()
		{
			if (CurrentToken == "(")
			{
				NextToken();  // Consume '('
				ParseExpression();
				Expect(")");  // Expect ')'
			}
			else if (IsNumber(CurrentToken))
			{
				ParseNumber();
			}
			else
			{
				throw new Exception($"Syntax Error: Unexpected token '{CurrentToken}' in factor.");
			}
		}

		// Grammar Rule: <Number> ::= "0" | "1" | "2" | ... | "9"
		private void ParseNumber()
		{
			if (IsNumber(CurrentToken))
			{
				NextToken();  // Consume the number
			}
			else
			{
				throw new Exception($"Syntax Error: Expected a number, but found '{CurrentToken}'.");
			}
		}

		// Helper method to check if the current token is a number
		private bool IsNumber(string token)
		{
			return token != null && Regex.IsMatch(token, @"^\d$");
		}

		// Helper method to ensure the current token matches the expected token
		private void Expect(string expected)
		{
			if (CurrentToken == expected)
			{
				NextToken();
			}
			else
			{
				throw new Exception($"Syntax Error: Expected '{expected}', but found '{CurrentToken}'.");
			}
		}

		// Tokenizer that breaks input into individual tokens
		private List<string> Tokenize(string input)
		{
			string pattern = @"(?<number>\d)|(?<operator>[+\-*/])|(?<symbol>[()])";
			List<string> tokens = new List<string>();

			foreach (Match match in Regex.Matches(input, pattern))
			{
				if (match.Groups["number"].Success)
				{
					tokens.Add(match.Groups["number"].Value);
				}
				else if (match.Groups["operator"].Success)
				{
					tokens.Add(match.Groups["operator"].Value);
				}
				else if (match.Groups["symbol"].Success)
				{
					tokens.Add(match.Groups["symbol"].Value);
				}
			}

			return tokens;
		}
	}
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Enter an arithmetic expression:");
			string input = Console.ReadLine();  // Take user input for the expression

			Parser parser = new Parser(input);

			try
			{
				parser.Parse();
				Console.WriteLine("Input is syntactically correct.");
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
	}
}
