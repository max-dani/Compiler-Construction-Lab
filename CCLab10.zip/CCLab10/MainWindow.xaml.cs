﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace CCLab10
{
	public partial class MainWindow : Window
	{
		// Define the grammar terminals and non-terminals
		private static readonly List<string> ValidTokens = new List<string>
		{
			"begin", "end", "int", "float", "if", "for", "else", "then", "print", "+", "=", "<", "(", ")", "{", "}", ";",
			"a", "b", "c", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0.1", "2.3"  // Variables and constants
        };

		// Sample action and goto tables (simplified)
		// Action table (state, terminal symbol) -> action
		private static readonly Dictionary<int, Dictionary<string, string>> ActionTable = new Dictionary<int, Dictionary<string, string>>()
		{
			{ 0, new Dictionary<string, string> { { "begin", "shift 1" }, { "int", "shift 2" }, { "float", "shift 3" } } },
			{ 1, new Dictionary<string, string> { { "int", "shift 2" }, { "float", "shift 3" }, { "print", "shift 4" } } },
			{ 2, new Dictionary<string, string> { { "var", "reduce S→int var=expr;" } } }, // E.g., "int a=5;"
            // Define other states
        };

		// Define the GOTO table for non-terminal transitions
		private static readonly Dictionary<int, Dictionary<string, int>> GotoTable = new Dictionary<int, Dictionary<string, int>>()
		{
			{ 0, new Dictionary<string, int> { { "stmt", 5 } } },
			{ 1, new Dictionary<string, int> { { "stmt", 6 } } },
            // Define other GOTO states
        };

		public MainWindow()
		{
			InitializeComponent();
		}

		// Parse button click event
		private void ParseButton_Click(object sender, RoutedEventArgs e)
		{
			string input = InputTextBox.Text.Trim();

			if (IsValidSLRInput(input))
			{
				ResultTextBlock.Text = "Input accepted by SLR parser!";
			}
			else
			{
				ResultTextBlock.Text = "Input rejected by SLR parser.";
			}
		}

		// Check if the input string is valid according to the grammar
		private bool IsValidSLRInput(string input)
		{
			Stack<int> stateStack = new Stack<int>();
			List<string> inputTokens = TokenizeInput(input);

			int currentState = 0;
			stateStack.Push(currentState);

			while (inputTokens.Count > 0)
			{
				string currentToken = inputTokens[0];
				inputTokens.RemoveAt(0);

				// Check the action for the current state and token
				if (ActionTable.ContainsKey(currentState) && ActionTable[currentState].ContainsKey(currentToken))
				{
					string action = ActionTable[currentState][currentToken];
					if (action.StartsWith("shift"))
					{
						currentState = int.Parse(action.Substring(6)); // Get next state from the action
						stateStack.Push(currentState);
					}
					else if (action.StartsWith("reduce"))
					{
						// Apply the reduction rule here (simplified)
						stateStack.Pop();
						// Adjust state based on the GOTO table
						currentState = GotoTable[stateStack.Peek()][action.Substring(7)]; // Next state after reduction
					}
				}
				else
				{
					return false; // Invalid token or transition
				}
			}

			return stateStack.Count == 1 && stateStack.Peek() == 0; // Accept if parser reaches start state
		}

		// Tokenize the input string into individual tokens
		private List<string> TokenizeInput(string input)
		{
			List<string> tokens = new List<string>();
			string[] splitTokens = input.Split(new[] { ' ', '\t', '\n', '(', ')', '{', '}', ';', '+', '=', '<' }, StringSplitOptions.RemoveEmptyEntries);

			foreach (var token in splitTokens)
			{
				if (ValidTokens.Contains(token))
				{
					tokens.Add(token);
				}
				else
				{
					return new List<string>(); // Invalid token
				}
			}

			return tokens;
		}
	}
}
