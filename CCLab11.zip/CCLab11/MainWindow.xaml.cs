﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CCLab11
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void TranslateButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				ParseTreeView.Items.Clear();
				OutputTextBox.Clear();

				var translator = new GrammarTranslator();
				var result = translator.Translate(InputTextBox.Text);

				// Display the parse tree
				var rootNode = translator.GetParseTree();
				ParseTreeView.Items.Add(CreateTreeViewItem(rootNode));

				// Display the translation
				OutputTextBox.Text = result;
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error: {ex.Message}", "Translation Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private TreeViewItem CreateTreeViewItem(Node node)
		{
			var item = new TreeViewItem();
			item.Header = $"{node.Symbol} → {node.Translation}";

			foreach (var child in node.Children)
			{
				item.Items.Add(CreateTreeViewItem(child));
			}

			return item;
		}
	}

	public class Node
	{
		public string Symbol { get; set; }
		public string Translation { get; set; }
		public List<Node> Children { get; set; } = new List<Node>();
	}

	public class GrammarTranslator
	{
		private int position;
		private string input;
		private Node parseTree;

		public string Translate(string input)
		{
			this.input = input;
			this.position = 0;

			// Start with S production
			parseTree = S();

			if (position != input.Length)
			{
				throw new Exception("Input not fully consumed");
			}

			return parseTree.Translation;
		}

		public Node GetParseTree() => parseTree;

		private Node S()
		{
			var node = new Node { Symbol = "S" };

			// S → AA
			var a1 = A();
			var a2 = A();

			node.Children.Add(a1);
			node.Children.Add(a2);
			node.Translation = a1.Translation + a2.Translation;

			return node;
		}

		private Node A()
		{
			var node = new Node { Symbol = "A" };

			if (position >= input.Length)
			{
				throw new Exception("Unexpected end of input");
			}

			// A → aA
			if (input[position] == 'a')
			{
				position++;
				var childA = A();
				node.Children.Add(new Node { Symbol = "a", Translation = "a" });
				node.Children.Add(childA);
				node.Translation = "a" + childA.Translation;
			}
			// A → b
			else if (input[position] == 'b')
			{
				position++;
				node.Children.Add(new Node { Symbol = "b", Translation = "b" });
				node.Translation = "b";
			}
			else
			{
				throw new Exception($"Unexpected character at position {position}: {input[position]}");
			}

			return node;
		}
	}
}