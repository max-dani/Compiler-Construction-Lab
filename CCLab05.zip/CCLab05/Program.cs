﻿using System;
using System.Collections.Generic;

namespace CCLab05
{
	internal class Program
	{
		static void Main(string[] args)
		{
			SymbolTable symbolTable = new SymbolTable();

			// Insert symbols
			symbolTable.Insert("x", "int", 10);
			symbolTable.Insert("y", "float", 20.5);
			symbolTable.Insert("z", "string", "Hello");

			// Display symbols
			symbolTable.DisplaySymbols();

			// Lookup a symbol
			Symbol symbol = symbolTable.Lookup("x");
			if (symbol != null)
			{
				Console.WriteLine($"Found symbol: {symbol}");
			}

			// Delete a symbol
			symbolTable.Delete("y");

			// Try to lookup a deleted symbol
			symbolTable.Lookup("y");

			// Display remaining symbols
			symbolTable.DisplaySymbols();
		}
	}
	public class Symbol
	{
		public string Name { get; set; }
		public string Type { get; set; }
		public object Value { get; set; }

		public Symbol(string name, string type, object value)
		{
			Name = name;
			Type = type;
			Value = value;
		}

		public override string ToString()
		{
			return $"Name: {Name}, Type: {Type}, Value: {Value}";
		}
	}

	// Symbol table class with hash function (using Dictionary)
	public class SymbolTable
	{
		private Dictionary<string, Symbol> table;

		public SymbolTable()
		{
			table = new Dictionary<string, Symbol>();
		}

		// Insert a new symbol
		public void Insert(string name, string type, object value)
		{
			if (!table.ContainsKey(name))
			{
				Symbol symbol = new Symbol(name, type, value);
				table[name] = symbol;
				Console.WriteLine($"Inserted symbol: {symbol}");
			}
			else
			{
				Console.WriteLine($"Symbol {name} already exists in the table.");
			}
		}

		// Lookup a symbol by name
		public Symbol Lookup(string name)
		{
			if (table.ContainsKey(name))
			{
				return table[name];
			}
			else
			{
				Console.WriteLine($"Symbol {name} not found.");
				return null;
			}
		}

		// Delete a symbol by name
		public void Delete(string name)
		{
			if (table.ContainsKey(name))
			{
				table.Remove(name);
				Console.WriteLine($"Symbol {name} removed from the table.");
			}
			else
			{
				Console.WriteLine($"Symbol {name} not found.");
			}
		}

		// Display all symbols in the table
		public void DisplaySymbols()
		{
			Console.WriteLine("Symbol Table:");
			foreach (var entry in table)
			{
				Console.WriteLine(entry.Value);
			}
		}

		// Optional: Custom Hash Function (educational purpose)
		public int CustomHashFunction(string symbolName)
		{
			int hashValue = 0;
			foreach (char c in symbolName)
			{
				hashValue += c;
			}
			return hashValue % table.Count;
		}
	}
}
