﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows;

namespace CCLab04
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private List<string> tokens;
		private string buffer1; // First buffer (for current token)
		private string buffer2; // Second buffer (for input stream)
		public MainWindow()
		{
			InitializeComponent();
			tokens = new List<string>();
		}
		private void AnalyzeButton_Click(object sender, RoutedEventArgs e)
		{
			buffer2 = InputTextBox.Text;
			if (string.IsNullOrWhiteSpace(buffer2))
			{
				MessageBox.Show("Please enter some code to analyze.");
				return;
			}
			Tokenize(buffer2);
			TokenListBox.ItemsSource = tokens;

			// Clear the input box for the next entry
			InputTextBox.Clear();
		}

		private void Tokenize(string input)
		{
			tokens.Clear();
			buffer1 = ""; // Clear the first buffer

			// Regex patterns for different tokens
			string pattern = @"(?<keyword>if|else|while|return|int|float|double|void)|" + // Keywords
							 @"(?<identifier>[a-zA-Z_][a-zA-Z0-9_]*)|" + // Identifiers
							 @"(?<number>\d+)|" + // Numbers
							 @"(?<symbol>[{}();,])|"; // Symbols

			Regex regex = new Regex(pattern);

			foreach (Match match in regex.Matches(input))
			{
				if (match.Groups["keyword"].Success)
					tokens.Add("Keyword: " + match.Groups["keyword"].Value);
				else if (match.Groups["identifier"].Success)
					tokens.Add("Identifier: " + match.Groups["identifier"].Value);
				else if (match.Groups["number"].Success)
					tokens.Add("Number: " + match.Groups["number"].Value);
				else if (match.Groups["symbol"].Success)
					tokens.Add("Symbol: " + match.Groups["symbol"].Value);
			}
		}
	}
}