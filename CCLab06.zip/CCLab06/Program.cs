﻿using System.Text.RegularExpressions;
using System;
using System.Collections.Generic;

namespace CCLab06
{

	public class Parser
	{
		private readonly List<string> tokens;
		private int currentTokenIndex = 0;

		public Parser(string input)
		{
			// Tokenize input using a proper tokenizer
			tokens = Tokenize(input);
		}

		private string CurrentToken => currentTokenIndex < tokens.Count ? tokens[currentTokenIndex] : null;

		private void NextToken() => currentTokenIndex++;

		public void ParseProgram()
		{
			ParseStatementList();
		}

		private void ParseStatementList()
		{
			while (CurrentToken != null && CurrentToken != "}")
			{
				ParseStatement();
			}
		}

		private void ParseStatement()
		{
			if (CurrentToken == "int" || CurrentToken == "float")
			{
				ParseDeclaration();
			}
			else if (CurrentToken == "if")
			{
				ParseIfStatement();
			}
			else if (CurrentToken == "while")
			{
				ParseWhileStatement();
			}
			else if (IsIdentifier(CurrentToken))
			{
				ParseAssignment();
			}
			else
			{
				throw new Exception("Syntax Error: Invalid statement.");
			}
		}

		private void ParseDeclaration()
		{
			ParseType();
			ParseIdentifier();
			Expect(";");
		}

		private void ParseAssignment()
		{
			ParseIdentifier();
			Expect("=");
			ParseExpression();
			Expect(";");
		}

		private void ParseIfStatement()
		{
			Expect("if");
			Expect("(");
			ParseExpression();
			Expect(")");
			Expect("{");
			ParseStatementList();
			Expect("}");
		}

		private void ParseWhileStatement()
		{
			Expect("while");
			Expect("(");
			ParseExpression();
			Expect(")");
			Expect("{");
			ParseStatementList();
			Expect("}");
		}

		private void ParseExpression()
		{
			ParseTerm();
			while (CurrentToken == "+" || CurrentToken == "-" || CurrentToken == ">" || CurrentToken == "<" || CurrentToken == ">=" || CurrentToken == "<=" || CurrentToken == "==")
			{
				NextToken(); // consume operator
				ParseTerm();
			}
		}

		private void ParseTerm()
		{
			ParseFactor();
			while (CurrentToken == "*" || CurrentToken == "/")
			{
				NextToken(); // consume operator
				ParseFactor();
			}
		}

		private void ParseFactor()
		{
			if (IsIdentifier(CurrentToken))
			{
				ParseIdentifier();
			}
			else if (IsNumber(CurrentToken))
			{
				ParseNumber();
			}
			else if (CurrentToken == "(")
			{
				Expect("(");
				ParseExpression();
				Expect(")");
			}
			else
			{
				throw new Exception("Syntax Error: Invalid factor.");
			}
		}

		private void ParseType()
		{
			if (CurrentToken == "int" || CurrentToken == "float")
			{
				NextToken();
			}
			else
			{
				throw new Exception("Syntax Error: Invalid type.");
			}
		}

		private void ParseIdentifier()
		{
			if (IsIdentifier(CurrentToken))
			{
				NextToken();
			}
			else
			{
				throw new Exception("Syntax Error: Invalid identifier.");
			}
		}

		private void ParseNumber()
		{
			if (IsNumber(CurrentToken))
			{
				NextToken();
			}
			else
			{
				throw new Exception("Syntax Error: Invalid number.");
			}
		}

		private void Expect(string expected)
		{
			if (CurrentToken == expected)
			{
				NextToken();
			}
			else
			{
				throw new Exception($"Syntax Error: Expected {expected}, found {CurrentToken}");
			}
		}

		private bool IsIdentifier(string token)
		{
			return !string.IsNullOrEmpty(token) && char.IsLetter(token[0]);
		}

		private bool IsNumber(string token)
		{
			return int.TryParse(token, out _);
		}

		// Tokenizer that properly handles multi-character operators and symbols
		private List<string> Tokenize(string input)
		{
			string pattern = @"(?<identifier>[a-zA-Z_][a-zA-Z0-9_]*)|(?<number>\d+)|(?<operator>[+\-*/=><!]+)|(?<symbol>[{}();])";
			List<string> tokens = new List<string>();

			foreach (Match match in Regex.Matches(input, pattern))
			{
				if (match.Groups["identifier"].Success)
				{
					tokens.Add(match.Groups["identifier"].Value);
				}
				else if (match.Groups["number"].Success)
				{
					tokens.Add(match.Groups["number"].Value);
				}
				else if (match.Groups["operator"].Success)
				{
					tokens.Add(match.Groups["operator"].Value);
				}
				else if (match.Groups["symbol"].Success)
				{
					tokens.Add(match.Groups["symbol"].Value);
				}
			}

			return tokens;
		}
	}
	internal class Program
	{

		static void Main(string[] args)
		{
			string input = @"
                int x;
                float y;
                x = 10 + 20;
                y = x * 2;
                if (x > 10) {
                    x = x - 1;
                }
                while (x < 20) {
                    x = x + 1;
                }
            ";

			Parser parser = new Parser(input);
			try
			{
				parser.ParseProgram();
				Console.WriteLine("Input is syntactically correct.");
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
	}
}
