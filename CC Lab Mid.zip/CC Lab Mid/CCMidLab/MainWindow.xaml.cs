﻿// MainWindow.xaml.cs
using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Linq;
using System.Text;

namespace CCMidLab
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void GeneratePassword_Click(object sender, RoutedEventArgs e)
		{
			string registrationNumberLast2Digits = RegistrationNumberTextBox.Text.Trim();
			char firstNameSecondLetter = GetSecondLetter(FirstNameTextBox.Text.Trim());
			char lastNameSecondLetter = GetSecondLetter(LastNameTextBox.Text.Trim());
			string favoriteMovieChars = FavoriteMovieTextBox.Text.Trim();
			int requiredLength = 14;
			string specialChars = "!$%&()*+,-./:;<=>?@[\\]^_`{|}~";

			string password = GeneratePassword(registrationNumberLast2Digits, firstNameSecondLetter, lastNameSecondLetter, favoriteMovieChars, specialChars, requiredLength);

			string pattern = $@"^(?!.*#).{{{requiredLength}}}$";
			Regex regex = new Regex(pattern);

			if (regex.IsMatch(password))
			{
				OutputPasswordTextBox.Text = password;
			}
			else
			{
				OutputPasswordTextBox.Text = "Password generation failed.";
			}
		}

		private static string GeneratePassword(string regDigits, char firstLetter, char lastLetter, string movieChars, string specialChars, int length)
		{
			Random random = new Random();
			StringBuilder passwordBuilder = new StringBuilder();

			passwordBuilder.Append(regDigits);
			passwordBuilder.Append(firstLetter);
			passwordBuilder.Append(lastLetter);
			passwordBuilder.Append(movieChars);

			for (int i = 0; i < 5; i++)
			{
				passwordBuilder.Append(specialChars[random.Next(specialChars.Length)]);
			}

			while (passwordBuilder.Length < length)
			{
				passwordBuilder.Append((char)random.Next(33, 127));
			}

			char[] passwordArray = passwordBuilder.ToString().ToCharArray();
			for (int i = 0; i < passwordArray.Length; i++)
			{
				int j = random.Next(passwordArray.Length);
				char temp = passwordArray[i];
				passwordArray[i] = passwordArray[j];
				passwordArray[j] = temp;
			}

			return new string(passwordArray);
		}

		private char GetSecondLetter(string name)
		{
			if (name.Length < 2) return ' ';
			return name[1]; // return the second character
		}
	}
}